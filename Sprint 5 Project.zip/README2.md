Sprint 5 Storytelling with Data Project Tableau Public Link  https://public.tableau.com/app/profile/gemma.powell/viz/Book6_17542685235470/SEASONAL-FIRSTAPPROACH?publish=yes

Loom Presentation Link https://www.loom.com/share/4f007320a2084d218b61013b17599d91